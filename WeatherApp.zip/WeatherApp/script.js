const apiKey = "664ab23cace345abadb80132252006";

document.getElementById('getWeatherBtn').addEventListener('click', () => {
  const city = document.getElementById('locationInput').value.trim();
  if (!city) {
    alert("Please enter a city name.");
    return;
  }
  const url = `http://api.weatherapi.com/v1/current.json?key=${apiKey}&q=${city}`;
  fetchWeather(url);
});

document.getElementById('useLocationBtn').addEventListener('click', () => {
  navigator.geolocation.getCurrentPosition(position => {
    const lat = position.coords.latitude;
    const lon = position.coords.longitude;
    const url = `http://api.weatherapi.com/v1/current.json?key=${apiKey}&q=${lat},${lon}`;
    fetchWeather(url);
  }, () => {
    alert("Location access denied or not available.");
  });
});

function fetchWeather(url) {
  fetch(url)
    .then(res => res.json())
    .then(data => {
      displayWeather(data);
      saveToServer(data); // Send to Java backend
    });
}

function displayWeather(data) {
  const html = `
    <h2>${data.location.name}, ${data.location.country}</h2>
    <p><strong>Temperature:</strong> ${data.current.temp_c}°C</p>
    <p><strong>Condition:</strong> ${data.current.condition.text}</p>
    <img src="https:${data.current.condition.icon}" alt="icon">
  `;
  document.getElementById('weatherInfo').innerHTML = html;
}

fetch("http://localhost:8080/WeatherApp/saveWeather", {
  method: "POST",
  headers: {
    "Content-Type": "application/json"
  },
  body: JSON.stringify({
    city: data.location.name,
    country: data.location.country,
    temperature: data.current.temp_c,
    weather_condition: data.current.condition.text
  })
})
.then(res => res.json())
.then(result => {
  console.log("Response from server:", result);
  alert(result.status === "success" ? "Saved!" : "Error: " + result.message);
})
.catch(err => {
  console.error("Fetch error:", err);
});



