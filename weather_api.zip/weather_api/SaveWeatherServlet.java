// // SaveWeatherServlet.java
import java.io.*;
import jakarta.servlet.*;
import jakarta.servlet.http.*;
import java.sql.*;
import org.json.JSONObject;

public class SaveWeatherServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        System.out.println("=== doPost CALLED ===");

        StringBuilder sb = new StringBuilder();
        BufferedReader reader = request.getReader();
        String line;
        while ((line = reader.readLine()) != null) {
            sb.append(line);
        }

        try {
            System.out.println("Raw JSON Input: " + sb.toString());

            JSONObject json = new JSONObject(sb.toString());
            String city = json.getString("city");
            String country = json.getString("country");
            float temperature = (float) json.getDouble("temperature");
            String condition = json.getString("weather_condition");

            System.out.println("City: " + city);
            System.out.println("Country: " + country);
            System.out.println("Temperature: " + temperature);
            System.out.println("Condition: " + condition);

            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection conn = DriverManager.getConnection(
                "jdbc:mysql://localhost:3306/weather_db", "root", "Sameeksha@123");

            PreparedStatement stmt = conn.prepareStatement(
                "INSERT INTO weather (city, country, temperature, weather_condition) VALUES (?, ?, ?, ?)");
            stmt.setString(1, city);
            stmt.setString(2, country);
            stmt.setFloat(3, temperature);
            stmt.setString(4, condition);

            int rows = stmt.executeUpdate();
            System.out.println("Rows inserted: " + rows);

            conn.close();

            response.setContentType("application/json");
            response.getWriter().write("{\"status\":\"success\"}");

        } catch (Exception e) {
            e.printStackTrace();
            response.setContentType("application/json");
            response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            response.getWriter().write("{\"status\":\"error\",\"message\":\"" + e.getMessage() + "\"}");
        }
    }
}
